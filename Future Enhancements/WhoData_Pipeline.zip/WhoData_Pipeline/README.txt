Pipeline

Objective:

The objective for this module in the project is to provide an always up to date connection to the files hosted by the WHO so that they can be used by ChatGPT to provide the summarized output to the phone or app user. The main challenge is that ChatGPT does not perform optimally with tabular data, but rather is fine-tuned towards obtaining valuable information from written text. To optimize the data for this use, an Azure Synapse Pipeline is implemented, including the necessary transformation steps. Using a pipeline provides a repeatable and scalable process, which guarantees that the most up to date data is always accessible by this application, even as the volume of data increases. The modularity of the pipeline is also an additional benefit to this data connection process, as new tables can be easily added through the visual editor, following the same basic structure as the pre-existing tables.

Parts:

1. Connecting to the data:
The initial goal of this module was to use an HTTP connector to the web table available on the WHO's website, but that was not possible as the target data was in an embedded PowerBI report. Therefore, the data file is downloaded and stored in an Azure Blob container, which the dataflow, within the pipeline, accesses. This is the most urgent step to improve and modify, being able to directly connect to the WHO's source data is essential to obtaining timely and accurate data without the need to manually download and re-upload any files.

2.Data transformation steps:
The desired output is in sentence format, but the dataset also has many additional columns that are not relevant to the output. The first transformation step in the dataflow is to map the desired columns and rename them in a more user-friendly way. Depending on the dataset, the selected columns will be different.

3.Creation of text column:
The other important transformation step is to create the text column. This new column is described by a custom expression within a transformation step. This expression can be optimized for the desired use case and adapted to each different dataset. 

4.Exporting the data:
The last step is to export the final data as a text file, which can be provided to ChatGPT as context for the user questions. This file is exported to an Azure Blob container which can then be accessed with an SAS signature or by other means of authentication. Another possibility would be to export the dataset to the serverless SQL warehouse within Synapse and then using a Synapse notebook to call the ChatGPT API. This notebook would be triggered by a request from the app and would return the text provided by ChatGPT.

